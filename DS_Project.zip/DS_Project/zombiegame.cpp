#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iomanip>


using namespace std;

// Global Constants
const int MAP_WIDTH = 20;
const int MAP_HEIGHT = 10;
const char WALL = '#';
const char PLAYER = 'P';
const char ZOMBIE = 'Z';
const char SAFE_ZONE = 'S';
const char ITEM = '*';
const char EMPTY = ' ';
const char PATH = '.';
const int INF = 999999;
const int MAX_HIGH_SCORES = 10;



// High Score structure
struct HighScore
{
    string name;
    int score;
    bool won;
};





// Queue Implementation for Zombie Spawning and Movement
template <typename T>
class Queue {
private:
    struct QueueNode
    {
        T data;
        QueueNode* next;
        QueueNode(const T& d) : data(d), next(nullptr) {}
    };

    QueueNode* front;
    QueueNode* rear;
    int count;

public:
    Queue() : front(nullptr), rear(nullptr), count(0) {}

    ~Queue() 
    {
        while (!isEmpty()) 
        {
            dequeue();
        }
    }


    void enqueue(const T& data)
    {
        QueueNode* newNode = new QueueNode(data);
        if (isEmpty())
        {
            front = rear = newNode;
        }
        else {
            rear->next = newNode;
            rear = newNode;
        }
        count++;
    }

    void dequeue()
    {
        if (isEmpty()) return;

        QueueNode* temp = front;
        front = front->next;
        delete temp;
        count--;

        if (isEmpty())
        {
            rear = nullptr;
        }
    }

    T& peek() const
    {
        if (isEmpty()) 
            cout << "\nQueue is empty";
        return front->data;
    }

    bool isEmpty() const 
    {
        return count == 0;
    }

    int size() const
    {
        return count;
    }
};



// Priority Queue Implementation for finding shortest path and balances safety and rewards
template <typename T>
class PriorityQueue
{
private:
    struct PQNode
    {
        T data;
        int priority;
        PQNode* next;
        PQNode(const T& d, int p) : data(d), priority(p), next(nullptr) {}
    };

    PQNode* head;

public:
    PriorityQueue() : head(nullptr) {}

    ~PriorityQueue()
    {
        while (!isEmpty())
        {
            dequeue();
        }
    }

    void enqueue(const T& data, int priority)
    {
        PQNode* newNode = new PQNode(data, priority);

        if (isEmpty() || priority < head->priority)
        {
            newNode->next = head;
            head = newNode;
        }
     
        else 
        {
            PQNode* current = head;
            while (current->next && current->next->priority <= priority)
            {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
    }

    T dequeue()
    {
        if (isEmpty()) 
            cout << "\nPriorityQueue is empty";

        PQNode* temp = head;
        T data = temp->data;
        head = head->next;
        delete temp;
        return data;
    }

    bool isEmpty() const
    {
        return head == nullptr;
    }
};


template <typename T>
struct ListNode 
{
    T data;
    ListNode<T>* next;

    ListNode(const T& value, ListNode* nextNode = nullptr)
        : data(value), next(nextNode) {}
};


// Linked List Implementation to track collected items
template <typename T>
class LinkedList
{
    ListNode<T>* head;
    int count;

public:

    LinkedList() : head(nullptr), count(0) {}

    ~LinkedList()
    {
        ListNode<T>* current = head;
        while (current != nullptr)
        {
            ListNode<T>* next = current->next;
            delete current;
            current = next;
        }
    }

    void insertFront(const T& data)
    {
        ListNode<T>* newNode = new ListNode<T>(data);
        newNode->next = head;
        head = newNode;
        count++;
    }

    ListNode<T>* getHead() const
    { 
        return head;
    }

    bool isEmpty() const
    {
        return (count == 0 || head == nullptr);
    }

    int size() const
    {
        return count;
    }

};



// Graph Node Structure 
struct GraphNode 
{
    int x, y;
    bool walkable;

    struct Edge
    {
        GraphNode* neighbor;
        int weight;
        Edge(GraphNode* n, int w) : neighbor(n), weight(w) {}
    };


    LinkedList<Edge> edges; // Adjacency list of edges

    GraphNode(int x, int y) : x(x), y(y), walkable(true) {}
};



// Item structure
struct Item
{
    string name;
    int value;
    Item(string n, int v) : name(n), value(v) {}
};

// Zombie structure
struct Zombie 
{
    int x, y;
    Zombie(int x, int y) : x(x), y(y) {}
};

// Game Map Class
class GameMap
{
private:

    //Game layout Grid

    char grid[MAP_HEIGHT][MAP_WIDTH];
    char displayGrid[MAP_HEIGHT][MAP_WIDTH];
    GraphNode* nodes[MAP_HEIGHT][MAP_WIDTH];

    // Coordinates
    int playerX, playerY;
    int safeX, safeY;

    // Game Elements

    Queue<Zombie> zombies;
    LinkedList<Item> collectedItems;
    int score;
    int health;
    bool gameOver;
    bool gameWon;
    string playerName;


    // Initialize graph nodes for the grid and sets up edges for Dijkstra's alogrithm
    void initNodes()
    {

        // Create all nodes first

        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                nodes[y][x] = new GraphNode(x, y);
                nodes[y][x]->walkable = (grid[y][x] != WALL);  // non walkable if it's a wall
            }
        }

        // Connect each node to its walkable neighbors with edge weights

        for (int y = 0; y < MAP_HEIGHT; y++) 
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                if (!nodes[y][x]->walkable) 
                    continue;

                // checking UP
                if (y > 0 && nodes[y - 1][x]->walkable)
                {
                    int weight = (grid[y - 1][x] == ZOMBIE) ? 50 :
                        (grid[y - 1][x] == ITEM) ? 2 : 1;
                    nodes[y][x]->edges.insertFront(GraphNode::Edge(nodes[y - 1][x], weight));
                }

                // checking RIGHT

                if (x < MAP_WIDTH - 1 && nodes[y][x + 1]->walkable) 
                {
                    int weight = (grid[y][x + 1] == ZOMBIE) ? 50 :
                        (grid[y][x + 1] == ITEM) ? 2 : 1;
                    nodes[y][x]->edges.insertFront(GraphNode::Edge(nodes[y][x + 1], weight));
                }


                // checking DOWN

                if (y < MAP_HEIGHT - 1 && nodes[y + 1][x]->walkable)
                {
                    int weight = (grid[y + 1][x] == ZOMBIE) ? 50 :
                        (grid[y + 1][x] == ITEM) ? 2 : 1;
                    nodes[y][x]->edges.insertFront(GraphNode::Edge(nodes[y + 1][x], weight));
                }

                // checking LEFT

                if (x > 0 && nodes[y][x - 1]->walkable)
                {
                    int weight = (grid[y][x - 1] == ZOMBIE) ? 50 : (grid[y][x - 1] == ITEM) ? 2 : 1;
                    nodes[y][x]->edges.insertFront(GraphNode::Edge(nodes[y][x - 1], weight));
                }
            }
        }
    }


 // Path node for reconstruction
 struct PathNode
 {
        int x, y;
        PathNode* next;

        PathNode(int x, int y, PathNode* next = nullptr) : x(x), y(y), next(next) {}
 };

    // finding shortest path from start to end using Dijkstra 
    bool findPathDijkstra(GraphNode* start, GraphNode* end, PathNode*& pathHead)
    {

        int dist[MAP_HEIGHT][MAP_WIDTH];           // distance array
        pair<int, int> prev[MAP_HEIGHT][MAP_WIDTH];    // previous node for path tracing
        bool visited[MAP_HEIGHT][MAP_WIDTH];        // visited status

      
        // Initializing all cells
        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                dist[y][x] = INF;
                prev[y][x] = { -1, -1 };
                visited[y][x] = false;
            }
        }


        dist[start->y][start->x] = 0;

        PriorityQueue<pair<int, int>> pq;  // priority queue for Dijkstra
        pq.enqueue(make_pair(start->y, start->x), 0);

        while (!pq.isEmpty())
        {
            auto current = pq.dequeue();        // current node with smallest distance
            int y = current.first;
            int x = current.second;

            if (visited[y][x])             
                continue;

            visited[y][x] = true;

            if (y == end->y && x == end->x)      // reached destination
                break;


            // traverse neighbors with current node
            ListNode<GraphNode::Edge>* currentEdge = nodes[y][x]->edges.getHead();
            while (currentEdge != nullptr)
            {
                GraphNode* neighbor = currentEdge->data.neighbor;
                int weight = currentEdge->data.weight;

                int alt = dist[y][x] + weight;
                if (alt < dist[neighbor->y][neighbor->x])
                {
                    dist[neighbor->y][neighbor->x] = alt;
                    prev[neighbor->y][neighbor->x] = { y, x };
                    pq.enqueue(make_pair(neighbor->y, neighbor->x), alt);
                }

                currentEdge = currentEdge->next;
            }
        }

        // if no path is found

        if (prev[end->y][end->x].first == -1) return false;

        // Building path by backtracking from end to start 

        PathNode* path = nullptr;
        pair<int, int> current = { end->y, end->x };
        while (current.first != start->y || current.second != start->x)
        {
            path = new PathNode(current.second, current.first, path);
            current = prev[current.first][current.second];
        }

        pathHead = path;        // returning reconstructed path
        return true;
    }


    // Updating display grid with the current path marked by '.'

    void updateDisplayWithPath(PathNode* path) 
    {

        // Copy original grid to display grid

        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                displayGrid[y][x] = grid[y][x];
            }
        }

        // Marking path with dots

        PathNode* current = path;

        while (current != nullptr)
        {
            if (displayGrid[current->y][current->x] == EMPTY)
            {
                displayGrid[current->y][current->x] = PATH;
            }
            current = current->next;
        }

        // Ensure player and safe zone are visible
        displayGrid[playerY][playerX] = PLAYER;
        displayGrid[safeY][safeX] = SAFE_ZONE;
    }

    // Update display without path for manual mode
    void updateDisplay() 
    {
        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                displayGrid[y][x] = grid[y][x];
            }
        }
    }

    // counting the number of steps in path

    int countPathLength(PathNode* path)
    {
        int count = 0;
        PathNode* current = path;
        while (current != nullptr)
        {
            count++;
            current = current->next;
        }
        return count;
    }

    // Free the dynamically allocated path nodes

    void freePath(PathNode* path)
    {
        while (path != nullptr)
        {
            PathNode* temp = path;
            path = path->next;
            delete temp;
        }
    }


     // Updating high score file  

    void saveGameResults()
    {
        // Read existing high scores
        HighScore scores[MAX_HIGH_SCORES + 1]; // +1 for new score
        int count = 0;

        ifstream inFile("high_scores.txt");
        if (inFile.is_open())
        {
            while (count < MAX_HIGH_SCORES &&
                inFile >> scores[count].name >> scores[count].won >> scores[count].score) 
            {
                count++;
            }
          
            inFile.close();
        }

        // Add current game result
        scores[count].name = playerName;
        scores[count].score = score;
        scores[count].won = gameWon;
        count++;

       // Bubble sorting the scores
       
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - i - 1; j++) 
            {
                if (scores[j].score < scores[j + 1].score)
                {
                    // Swap
                    HighScore temp = scores[j];
                    scores[j] = scores[j + 1];
                    scores[j + 1] = temp;
                }
            }
        }


        // Keeping only top 10 scores
        if (count > MAX_HIGH_SCORES)
        {
            count = MAX_HIGH_SCORES;
        }


        // Writing back to file

        ofstream outFile("high_scores.txt");
        if (outFile.is_open()) {
            for (int i = 0; i < count; i++) 
            {
                outFile << scores[i].name << " "
                    << (scores[i].won ? "1" : "0") << " "
                    << scores[i].score << endl;
            }
            outFile.close();
        }
       
        else
        {
            cout << "Unable to save high scores." << endl;
        }

    }

public:

    // Constructor

    GameMap() : score(0), health(100), gameOver(false), gameWon(false), playerName("Player") 
    {
        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                grid[y][x] = EMPTY;
                displayGrid[y][x] = EMPTY;
                nodes[y][x] = nullptr;
            }
        }
    }


    // Destructor

    ~GameMap()
    {
        for (int y = 0; y < MAP_HEIGHT; y++) 
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                delete nodes[y][x];
            }
        }
    }


    void resetGame()
    {
        // Clear the grid and nodes
        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                grid[y][x] = EMPTY;
                displayGrid[y][x] = EMPTY;
              
                if (nodes[y][x] != nullptr)
                {
                    delete nodes[y][x];
                    nodes[y][x] = nullptr;
                }
            }
        }

        // Clear zombies
        while (!zombies.isEmpty())
        {
            zombies.dequeue();
        }


        // Clear collected items
        collectedItems.~LinkedList();
        new (&collectedItems) LinkedList<Item>();

        // Reset player stats
        score = 0;
        health = 100;
        gameOver = false;
        gameWon = false;
        playerName = "Player";
    }


    // Loading Game Frame

    void loadDefaultMap()
    {
        // Border walls
        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                if (x == 0 || x == MAP_WIDTH - 1 || y == 0 || y == MAP_HEIGHT - 1)
                {
                    grid[y][x] = WALL;
                }
            }
        }

        // Placing internal walls at specific positions  
        grid[2][2] = WALL; grid[2][3] = WALL; grid[2][4] = WALL;
        grid[5][10] = WALL; grid[5][11] = WALL; grid[6][11] = WALL;
        grid[8][15] = WALL; grid[7][15] = WALL; grid[7][16] = WALL;

        // Placing player at starting position and marking safe zone
        playerX = 1; playerY = 1;
        grid[playerY][playerX] = PLAYER;
        safeX = MAP_WIDTH - 2; safeY = MAP_HEIGHT - 2;
        grid[safeY][safeX] = SAFE_ZONE;

        // Placing items on map
        grid[1][3] = ITEM;
        grid[4][5] = ITEM;
        grid[7][8] = ITEM;
        grid[3][15] = ITEM;

        spawnZombies(3);
        initNodes();
    }


    // Spawns a specified number of zombies at random positions

    void spawnZombies(int count)
    {
        srand(time(0));
        for (int i = 0; i < count; i++)
        {
            int x, y;
            do
            {
                x = 1 + rand() % (MAP_WIDTH - 2);       // avoid walls
                y = 1 + rand() % (MAP_HEIGHT - 2);
            } while (grid[y][x] != EMPTY);          // until an empty cell is found

            zombies.enqueue(Zombie(x, y));          // adding zombie to queue
            grid[y][x] = ZOMBIE;                // marking zombie on the map
        }
    }

    void display()
    {

        // Copying game state to display grid

        updateDisplay();

        // printing the map row by row

        for (int y = 0; y < MAP_HEIGHT; y++)
        {
            for (int x = 0; x < MAP_WIDTH; x++)
            {
                cout << displayGrid[y][x];
            }
            cout << endl;
        }


        // Displaying player stats

        cout << "Player: " << playerName << endl;
        cout << "Health: " << health << " | Score: " << score << " | Items: ";


        // Printing collected item names

        ListNode<Item>* currentItem = collectedItems.getHead();
        bool first = true;
        while (currentItem != nullptr)
        {
            if (!first) cout << ", ";
            cout << currentItem->data.name;
            first = false;
            currentItem = currentItem->next;
        }


        // If no items collected

        if (first)      
        {  
            cout << "None";
        }
       
        cout << endl;
    }


    // Player movement

    void movePlayer(char direction)
    {
        if (gameOver || gameWon) 
            return;

        int newX = playerX, newY = playerY;         // PLayer coordinates

        switch (toupper(direction))
        {
            case 'W': newY--;
                break;
            case 'D': newX++; 
                break;
            case 'S': newY++;
                break;
            case 'A': newX--;
                break;
            default:
                return;
        }


        // Checking new position is valid

        if (newX < 0 || newX >= MAP_WIDTH || newY < 0 || newY >= MAP_HEIGHT || grid[newY][newX] == WALL) 
        {
            return;
        }


        // If zombie is encountered, reduce health

        if (grid[newY][newX] == ZOMBIE)
        {
            health -= 20;
            if (health <= 0)
            {
                gameOver = true;
                cout << "Game Over! You were caught by zombies!" << endl;
                saveGameResults();
            }
            return;
        }


        // If an item is found, collect it

        if (grid[newY][newX] == ITEM)
        {
            collectItem(newX, newY);
        }


        // If safe zone reached, win the game

        if (newX == safeX && newY == safeY) 
        {
            gameWon = true;
            cout << "Congratulations! You reached the safe zone!" << endl;
            calculateFinalScore();
            return;
        }



        // Move player to new position

        grid[playerY][playerX] = EMPTY;
        playerX = newX;
        playerY = newY;
        grid[playerY][playerX] = PLAYER;


        // random chance to move zombies after player moves 

        if (rand() % 2 == 0)
        {
            moveZombies();
        }
    }


    // Handles collecting items at given coordinates

    void collectItem(int x, int y)
    {
        string itemNames[] = { "Medkit", "Food", "Ammo", "Battery" };
        int itemValues[] = { 15, 10, 5, 8 };
        int index = rand() % 4;         // randomly select item

        collectedItems.insertFront(Item(itemNames[index], itemValues[index]));       // adding item to inventory
        score += itemValues[index] * 10;        // updare score
        health += itemValues[index];            // increase health 
    }


    // Moving all zombies towards the player or randomly

    void moveZombies()
    {
        int zombieCount = zombies.size();
        for (int i = 0; i < zombieCount; i++) 
        {
            Zombie z = zombies.peek();          // get zombie
            zombies.dequeue();                  // remove from queue
            grid[z.y][z.x] = EMPTY;             // clear previous position

            int newX = z.x, newY = z.y;

            // 70% chance to move towards player

            if (rand() % 10 < 7)
            {
                if (z.x < playerX && grid[z.y][z.x + 1] != WALL && grid[z.y][z.x + 1] != ZOMBIE)
                    newX++;

                else if (z.x > playerX && grid[z.y][z.x - 1] != WALL && grid[z.y][z.x - 1] != ZOMBIE)
                    newX--;

                if (z.y < playerY && grid[z.y + 1][z.x] != WALL && grid[z.y + 1][z.x] != ZOMBIE)
                    newY++;

                else if (z.y > playerY && grid[z.y - 1][z.x] != WALL && grid[z.y - 1][z.x] != ZOMBIE)
                    newY--;
            }
         
            // 30% chance of moving randomly

            else
            {
                int r = rand() % 4;
                switch (r)
                {
                case 0: if (z.y > 0 && grid[z.y - 1][z.x] != WALL && grid[z.y - 1][z.x] != ZOMBIE)
                    newY--;
                    break;

                case 1: if (z.x < MAP_WIDTH - 1 && grid[z.y][z.x + 1] != WALL && grid[z.y][z.x + 1] != ZOMBIE) 
                    newX++;
                    break;

                case 2: if (z.y < MAP_HEIGHT - 1 && grid[z.y + 1][z.x] != WALL && grid[z.y + 1][z.x] != ZOMBIE) 
                    newY++;
                    break;

                case 3: if (z.x > 0 && grid[z.y][z.x - 1] != WALL && grid[z.y][z.x - 1] != ZOMBIE)
                    newX--;
                    break;
                }
            }


            // If zombie reaches player

            if (newX == playerX && newY == playerY)
            {
                health -= 30;
                if (health <= 0)
                {
                    gameOver = true;
                    saveGameResults();
                }
             

                // Zombie stays in place

                grid[z.y][z.x] = ZOMBIE;
                zombies.enqueue(z);
                continue;
            }

            // Updating zombie's position
            
            z.x = newX;
            z.y = newY;
            grid[z.y][z.x] = ZOMBIE;
            zombies.enqueue(z);
        }
    }


    // Calculating score after game ends

    void calculateFinalScore()
    {
        int itemScore = 0;
        ListNode<Item>* currentItem = collectedItems.getHead();
      
        while (currentItem != nullptr) 
        {
            itemScore += currentItem->data.value;
            currentItem = currentItem->next;
        }

        score = (itemScore * 10) - (zombies.size() * 5) +((abs(playerX - 1) + abs(playerY - 1)) * 2) + (health * 3);        
        cout << "Final Score: " << score << endl;
        saveGameResults();
    }



    void autoNavigate()
    {
        PathNode* path = nullptr;

        // Get current player position and safe zone

        GraphNode* start = nodes[playerY][playerX];
        GraphNode* end = nodes[safeY][safeX];


        // Finding path from player to safe zone using Dijkstra


        if (findPathDijkstra(start, end, path))
        {

            system("cls"); //clear screen command


            // Display path summary and path on grid

            cout << "Found path to safe zone! (" << countPathLength(path) << " steps)" << endl;
            updateDisplayWithPath(path);        // Marks the path visually for displayGrid
            display();
            cout << "Press Enter to start moving...";
            cin.ignore();           



            // Start player movement along the path 

            PathNode* currentStep = path;
            while (currentStep != nullptr && !gameOver && !gameWon)
            {

                system("cls");

                // Determine direction to move

                char ic = ' ';
                if (currentStep->y < playerY)
                    ic = 'W';

                else if (currentStep->y > playerY)
                    ic = 'S';

                else if (currentStep->x < playerX)
                    ic = 'A';

                else if (currentStep->x > playerX)
                    ic = 'D';

                movePlayer(ic);
                updateDisplayWithPath(currentStep->next);
                display();


                 
                if (gameOver || gameWon)
                    break;

                cout << "Press Enter to continue...";
                cin.ignore();
                currentStep = currentStep->next;
            }
            
            freePath(path);         // clean path memory
        }


        // If no path is found

        else
        {
            system("cls");

            cout << "No path to safe zone found!" << endl;
            cout << "Press Enter to continue...";
            cin.ignore();
        }
    }

    void setPlayerName(const string& name)
    {
        playerName = name;
    }


    bool isGameOver() const
    {
        return gameOver;
    }

    bool isGameWon() const
    { 
        return gameWon;
    }

};



    void displayHighScores()
    {

        system("cls");


        cout << "=== TOP 10 HIGH SCORES ===" << endl;
        cout << "--------------------------" << endl;
        cout << left << setw(20) << "PLAYER"
             << setw(10) << "STATUS"
             << "SCORE" << endl;
        cout << "--------------------------" << endl;

        ifstream inFile("high_scores.txt");
        if (inFile.is_open())
        {

            HighScore score;
            int won;
            int rank = 1;
          
            
            while (rank <= MAX_HIGH_SCORES && inFile >> score.name >> won >> score.score) 
            {
                score.won = (won == 1);
                cout << setw(2) << rank++ << ". "
                     << setw(17) << score.name
                     << setw(10) << (score.won ? "WON" : "LOST")
                     << score.score << endl;
        }

        inFile.close();
    }
  
    
    else
   {

        cout << "No high scores recorded yet." << endl;
    }

    cout << "--------------------------" << endl;
    cout << "Press Enter to return to menu...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}



int main() 
{
    srand(time(0));
    GameMap game;


    // Game Simulation

    while (true) 
    {
       
        system("cls");


        cout << "================================" << endl;
        cout << "=== ZOMBIE APOCALYPSE SURVIVAL ===" << endl;
        cout << "================================" << endl << endl << endl;

        cout << "========================================================================================================================" << endl;
        cout << "                                                   === Scenario ===" << endl;
        cout << "The world as you knew it ended last night. A mysterious virus turned your friends, family, and neighbors into flesh-craving zombies."
            << "You wake up in the heart of the quarantine zone � unarmed, alone, and surrounded by the undead.The military has abandoned the city."
            << "Your only hope? Fight your way out before the sun sets... or join the horde forever." << endl;
        cout << "========================================================================================================================" << endl << endl;

        cout << "================================" << endl;
        cout << "       ====   MENU   ====" << endl;
        cout << "1. Start New Game (Manual Mode)" << endl;
        cout << "2. Start New Game (Auto Mode)" << endl;
        cout << "3. View Instructions" << endl;
        cout << "4. View High Scores" << endl;
        cout << "5. Exit" << endl;
        cout << "================================" << endl << endl;

        cout << "================================" << endl;
        cout << "       Select option: " << endl;
        cout << "================================" << endl;


        int choice;
        cin >> choice;

        // Clear input buffer
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice)
        {

          // Manual Mode
         case 1:
         {       

            game.resetGame();           // reset game after each turn
            cout << "Enter your name: ";
            string playerName;
            getline(cin, playerName);
            game.setPlayerName(playerName);

            game.loadDefaultMap();
            cout << "\nManual Mode Controls:" << endl;
            cout << "W - Move Up" << endl;
            cout << "A - Move Left" << endl;
            cout << "S - Move Down" << endl;
            cout << "D - Move Right" << endl;
            cout << "Avoid zombies (Z) and reach the safe zone (S)!" << endl;
            cout << "Press Enter to begin...";
            cin.ignore();

            while (!game.isGameOver() && !game.isGameWon()) 
            {

                system("cls");

                game.display();
                cout << "Enter move (W/A/S/D): ";

                char input;
                cin >> input;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                game.movePlayer(input);
            }

            if (game.isGameWon()) 
            {
                cout << "\nCongratulations! You survived!" << endl;
            }
            
            else
            {
                cout << "\nGame Over! Try again!" << endl;
            }

            cout << "Press Enter to return to menu...";
            cin.ignore();
            break;
        }


         // Auto Mode
        case 2:
        {
           
            game.resetGame();                    // reset game after each turn
            cout << "Enter your name: ";
            string playerName;
            getline(cin, playerName);
            game.setPlayerName(playerName);

            game.loadDefaultMap();
            cout << "\nAuto Mode Selected" << endl;
            cout << "The game will automatically navigate to the safe zone. Press 'Enter' to move your player. " << endl;
            cout << "Path will be shown with dots (.)" << endl;
            cout << "Press Enter to begin...";
            cin.ignore();

            game.autoNavigate();

            if (game.isGameWon())
            {
                cout << "\n****YOU WIN!!*****" << endl;
            }
           
            else 
            {
                cout << "\n*****GAME OVER!!*****" << endl;
            }

            cout << "Press Enter to return to menu...";
            cin.ignore();
            break;
        }


        // Instructions
        case 3:
        {        

            system("cls");


            cout << "==========================================================================================" << endl;
            cout << "\n=== INSTRUCTIONS ===" << endl;
            cout << "1. Objective: Reach the safe zone (S)" << endl;
            cout << "2. Avoid zombies (Z) - they reduce your health" << endl;
            cout << "3. Collect items [Ammo/Medkit/Food/Battery] (*) - they increase health and score" << endl;
            cout << "4. Controls:" << endl;
            cout << "   W - Move Up" << endl;
            cout << "   A - Move Left" << endl;
            cout << "   S - Move Down" << endl;
            cout << "   D - Move Right" << endl;
            cout << "5. Auto Mode: It will show you the optimal path. Just Press Enter key to move your player." << endl;
            cout << "==========================================================================================" << endl;
            cout << "Press Enter to return to menu...";
            cin.ignore();
            break;
        }


        // View High Scores
        case 4:          
            displayHighScores();
            break;


        // Exit
        case 5:         
        {               
            cout << "=====================================================================================" << endl;
            cout << "The dead may rest, but the nightmare never ends... See you on the next run, survivor." << endl;
            cout << "=====================================================================================" << endl;
            return 0;
        }

        default:
            cout << "Invalid choice! Press Enter to try again...";
            cin.ignore();
        }
    }

    return 0;
}